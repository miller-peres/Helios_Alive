
void delay(short time);
void controlaFreeRunner(long tempoFreeRunner);
void  configuraFreeRunner(void);



