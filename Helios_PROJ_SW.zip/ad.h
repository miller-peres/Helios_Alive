
void InitAD(void);
