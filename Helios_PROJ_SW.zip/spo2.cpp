#include "spo2.h"
#include "lpc21xx.h"
#include "irq.h"
//#include "serial.h"

// DEFINI��ES DE CONFIG DE COM SPO2
#define   	COM0    	0
#define		UART1_INT	7
#define  	EVEN   		0
#define   	ODD    		1
#define	  	NONE		2
#define   	FOSC 		10000000              // Frequencia do cristal  = 10MHz.
#define   	PLL_M 		6 				   // PLL_M
#define   	VPBDIV_VAL	1			   // Sem multipliccao do clock
#define   	UART_BAUD(baud) (unsigned int)(((FOSC*PLL_M/VPBDIV_VAL) / ((baud) * 16.0)) + 0.5)
#define   	BIT_0  		0x00000001    //apenas define posicao do bit 0
#define 	BIT_1   	0x00000002    //apenas define posicao do bit 1
#define 	BIT_2  	 	0x00000004    //apenas define posicao do bit 2
#define 	BIT_3   	0x00000008    //apenas define posicao do bit 3
#define 	BIT_4   	0x00000010    //apenas define posicao do bit 4
#define 	BIT_16  	0x00010000    //apenas define posicao do bit 16
#define 	BIT_18  	0x00040000    //apenas define posicao do bit 18

// DEFINI��ES DE TRATAMENTO DE SPO2

//Defini��es de SPO2
#define PERDA_PULSO       		0x01
#define ARTEFATO          		0x02
#define SINAL_FRACO       		0x04
#define BUSCANDO_SINAL    		0x08
#define BUSCA_LONGA       		0x10
#define SENSOR_DESCONECTADO 	0x20
#define SEM_DEDO          		0x40
#define SPO2_OUT				0x80

#define PLETHMAX  				99
#define PLETHINVALID 			0x7F
#define SPO2INVALID 			0x7F
#define SPO2PRINVALID 			0x3FF
#define OXI_HUMAN				1
#define OXI_VET					2

#define IIR_PEND	0x01
#define IIR_RLS		0x03
#define IIR_RDA		0x02
#define IIR_CTI		0x06
#define IIR_THRE	0x01

#define LSR_RDR		0x01
#define LSR_OE		0x02
#define LSR_PE		0x04
#define LSR_FE		0x08
#define LSR_BI		0x10
#define LSR_THRE	0x20
#define LSR_TEMT	0x40
#define LSR_RXFE	0x80
#define BUFSIZE		0x100
unsigned char UART1Buffer[BUFSIZE];

Spo2::Spo2(){UART1TxEmpty = 1;}

void Spo2::config_COM_spo2()
{
	char port = COM0;
	char n = 8;
	char StopBits = 1;
	char Parity = NONE; 
	long bps = 115200;
	baud = UART_BAUD(bps);
	
	if (port != COM0) //SPO2
	{
	  //Habilita TXD1 e RXD1
	  PINSEL0 |= BIT_18 | BIT_16;
	  // Define numero de bits de dados
	  U1LCR = (n==7?BIT_1:(BIT_1 | BIT_0));
	  // Define stop bits...
	  U1LCR |= (StopBits==2?BIT_2:0);
	  // Define paridade ...
	  U1LCR |= ((Parity==EVEN)||(Parity==ODD)?BIT_3:0);
	  U1LCR |= ((Parity==EVEN)?BIT_4:0);
	  U1LCR |= 0x80;
	  U1DLL  = baud;			  
	  U1DLM  = (baud>>8);	
	  U1LCR &= ~(0x80);			
	  // Habilita int RDA e RX                                          
	  U1IER = BIT_0 | BIT_2;                           
		//  	  CONFIGURA_INTERRUPCAO_VIC(1,UartHandlerUART1,UART1);
	  install_irq (UART1_INT, (void *) Treat_Data_SPO2_BCI()__irq); //handler_FSM_spo2 UartHandlerUART1
	}
}

enum STATE_TREAT_DATA_SPO2_FSM
{
	PROBE_VERIFY = 0,
	PLETH_VALUE,
	SENSOR_CHECK,
	PULSE_RATE,
	SPO2_VALUE,
	SPO2_STATUS,
	GET_REVISION,
	VERIFY_STEP1,
	REVISION_VERIFY,
	VERIFY_STEP2,
	VERIFY_STEP3,
	ASSIGN_DATA,
};

void Spo2::Treat_Data_SPO2_BCI()__irq
{
	IENABLE;					/* handles nested interrupt */	
	IIRValue = U1IIR;

	IIRValue >>= 1;				/* skip pending bit in IIR */
	IIRValue &= 0x07;			/* check bit 1~3, interrupt identification */
	
	T1IR  = 0; 
	
	RxDado = U1RBR;		
	// if the synch bit is set, it is the start of a new packet, reset all values
	if (RxDado & 0x80)
	{
		gCountBCI = PROBE_VERIFY;
	}
	
	if (gMonitoraSpo2)
	{
		switch(gCountBCI)
		{
			case PROBE_VERIFY: //bits 0 - 3: Signal Strength (0xF = invalid)
			//bit 4: searching too long, bit
			//bit 5: Probe Unplugged
			//bit 6: pulse beep
			//bit 7: 1 (synch bit)
			if (RxDado & 0x80)
			{
				if (RxDado == 0x80)
				{
					gRevisionReady = 0x80;
				}
				//SignalStrength = (RxDado & 0x0F);
				gSearchTooLong = RxDado & 0x10;
				gProbebUnpluged = RxDado & 0x20;
				gPulseBeep = RxDado & 0x40;
				gCalculatedChecksum = RxDado;
				gCountBCI = PLETH_VALUE;
			}
			break;
			
			case PLETH_VALUE: //bits 0 - 6: Plethysmogram
				//bit 7: 0 (synch bit)
				if (!((gRevisionReady) && RxDado == 0x00))
				{
					gRevisionReady = 0;
					gPlethValue = RxDado;
					if (gPlethValue > PLETHMAX && gPlethValue != PLETHINVALID)
					{
						gPlethValue = PLETHMAX;
					}
				}
				gCalculatedChecksum +=  RxDado;
				gCountBCI = SENSOR_CHECK;
			break;
			
			case SENSOR_CHECK: //bits 0 - 3: Bargraph
				//bit 4: no finger in probe
				//bit 5: searching for pulse
				//bit 6: sleep mode indicator bit
				//bit 7: 0 (synch bit)
				if (gRevisionReady)
				gRevisionString[0] = RxDado;
				else
				{
					gOxBar = RxDado & 0xF;
					gCheckSensor = RxDado & 0x10;
					gSearching = RxDado & 0x20;
					//SleepMode = RxDado & 0x40;
				}
				//gCalculatedChecksum += (unsigned int) RxDado
				gCalculatedChecksum += RxDado;
				gCountBCI = PULSE_RATE;
			break;
			
			case PULSE_RATE: //bits 0 - 6: Rate bits 0 - 6
				//bit 7: 0(synch bit)
				if (gRevisionReady)
				gRevisionString[1] = RxDado;
				else
				gPulseRate = RxDado & 0x7F;
				gCalculatedChecksum +=  RxDado;
				gCountBCI = SPO2_VALUE;
			break;
			
			case SPO2_VALUE: //bits 0 - 6: SpO2 bits 0 - 6
				//bit 7: 0(synch bit)
				if (gRevisionReady)
				gRevisionString[2] = RxDado;
				else
				{
					gSpO2Value = RxDado;
					if (gSpO2Value >= SPO2INVALID)
					gSpO2Value = SPO2INVALID;
				}
				gCalculatedChecksum +=  RxDado;
				gCountBCI = SPO2_STATUS;
			break;
			
			case SPO2_STATUS: //bits 0 - 1:
				// 00 = 4 beat SpO2 8 sec PR Averaging
				// 01 = 8 beat SpO2 8 sec PR Averaging
				// 10 = 16 beat SpO2 16 sec PR Averaging
				// 11 = 16 beat SpO2 8 sec PR Averaging
				//bit 2: artifact
				//bit 3: small Pulse
				//bit 4: Revision Level Reply
				//bit 5: Lost Pulse
				//bit 6: disable auto pleth scaling
				//bit 7: 0 (synch bit)
			if (gRevisionReady)
			{
				gRevisionString[3] = '.';
				gRevisionString[4] = RxDado;
			}
			else
			{
				//OxAveragingSetting = RxDado & 0x03;
				gArtifact = RxDado & 0x04;
				gSmallPulse = RxDado & 0x08;
				gLostPulse = RxDado & 0x20;
				//AutoSynchOff = RxDado & 0x40;
			}
			gCalculatedChecksum +=  RxDado;
			gCountBCI = GET_REVISION;
			break;
			
			case GET_REVISION:
				//bits 0 - 6: Perfusion Index bits 0 - 6
				//bit 7: 0 (synch bit)
				if (gRevisionReady )
				{
					gRevisionString[5] = RxDado;
				}
				else
					//PerfusionIndex = (unsigned int)RxDado
					gCalculatedChecksum +=  RxDado;
					gCountBCI = VERIFY_STEP1;
			break;
			
			case VERIFY_STEP1:
				//bits 0 - 4: Perfusion Index bits 7 - 11
				//bit 5 1 = PI Sensitivity is ON
				//bit 7: 0 (synch bit)
				if (!(gRevisionReady))
				{
					//PISensitivity = RxDado & 0x20;
					//PerfusionIndex += (unsigned int)(RxDado & 0x1F) * 128;
				}
				gCalculatedChecksum +=  RxDado;
				gCountBCI = REVISION_VERIFY;
			break;
			
			case REVISION_VERIFY:
				//bits 0-2: Rate bits 7-9
				//bits 3-6: Unused
				//bit 7: 0 (synch bit)
				if (gRevisionReady == 0)
				{
					gPulseRate += (RxDado & 0x07) * 128;
					if (gPulseRate >= SPO2PRINVALID)
					gPulseRate = SPO2PRINVALID;
				}
				gCalculatedChecksum += RxDado;
				gCountBCI = VERIFY_STEP2;
			break;
			
			case VERIFY_STEP2:
				//bits 0-6: Spare
				//bit 7: 0 (synch bit)
				gCalculatedChecksum += RxDado;
				gCountBCI = VERIFY_STEP3;
			break;
				
			case VERIFY_STEP3:
				//bits 0-6 Checksum Bits 0-6
				//bit 7: 0 (synch bit)
				gReceivedChecksum = RxDado;
				gCountBCI = ASSIGN_DATA;
			break;
			
			case ASSIGN_DATA: // PEGA CURVA
				//bits 0-6 Checksum Bits 7-13
				//bit 7: 0 (synch bit)
				gReceivedChecksum += RxDado * 128;
				if (gCalculatedChecksum + gReceivedChecksum == 16384)
				{
					if(!gDemo)
					{
						 Set_status_spo2((gLostPulse >> 5) | (gArtifact >> 1) | (gSmallPulse >> 1) | (gSearching >> 2) | gSearchTooLong | gProbebUnpluged | (gCheckSensor << 2));
						
						if(Get_status_spo2() & (gProbebUnpluged | (gCheckSensor << 2)))
						{
							gCurvaSpo2 = 0;
							gValorSpo2 = 0;
							gBpmSpo2 = 0;
						}
						else
						{	
							Set_curva_spo2(gPlethValue);
							Set_bpm_spo2(gSpO2Value);
							
							if(gValorSpo2 == 127)
							{	
								gValorSpo2 = 0;
							}
							Set_bpm_spo2(gPulseRate);
							if(gBpmSpo2 > 254)
							{
								gBpmSpo2 = 0;
							}
						}
						if(gRevisionString[0])
						{
							if(gRevisionString[0] == 'A' && gRevisionString[1] == 'L')
							{
								gOxiModel = OXI_HUMAN;
							}
							else if(gRevisionString[0] == 'A' && gRevisionString[1] == 'V')
							{	
								gOxiModel = OXI_VET;
							}
						} 
					}
				}
				else
				{
					//BadChecksum = 1;
				}
				gCountBCI = PROBE_VERIFY;
			break;
				
			default: //something went wrong, don't depend on the data
				gCountBCI = PROBE_VERIFY;
			break;
		}
	}
	else
		gStatusSpo2 = 0;
		
	
	if(IIRValue == IIR_RLS)		/* Receive Line Status */
	{
		LSRValue = U1LSR;
		/* Receive Line Status */
		if ( LSRValue & (LSR_OE|LSR_PE|LSR_FE|LSR_RXFE|LSR_BI) )
		{
			/* There are errors or break interrupt */
			/* Read LSR will clear the interrupt */
			UART1Status = LSRValue;
			Dummy = U1RBR;		/* Dummy read on RX to clear 
			interrupt, then bail out */
			Dummy = Dummy & 0xFF;
			IDISABLE;
			VICVectAddr = 0;		/* Acknowledge Interrupt */
			return;
		}
		if ( LSRValue & LSR_RDR )	/* Receive Data Ready */			
		{
			/* If no error on RLS, normal ready, save into the data buffer. */
			/* Note: read RBR will clear the interrupt */
			UART1Buffer[UART1Count] = U1RBR;
			UART1Count++;
			if ( UART1Count == BUFSIZE )  // definido como BUFSIZE = 0x100
			{
				UART1Count = 0;		/* buffer overflow */
			}
			
		}
		else if ( IIRValue == IIR_RDA )	/* Receive Data Available */
		{
			/* Receive Data Available */
			UART1Buffer[UART1Count] = U1RBR;
			UART1Count++;	
			if ( UART1Count == BUFSIZE )
			{
				UART1Count = 0;		/* buffer overflow */
			}
		}
	}
	else if ( IIRValue == IIR_CTI )	/* Character timeout indicator */
	{
		/* Character Time-out indicator */
		UART1Status |= 0x100;		/* Bit 9 as the CTI error */
	}
	else if ( IIRValue == IIR_THRE )	/* THRE, transmit holding register empty */
	{
		/* THRE interrupt */
		LSRValue = U1LSR;		/* Check status in the LSR to see if
		valid data in U0THR or not */
		if ( LSRValue & LSR_THRE )
		{
			UART1TxEmpty = 1;
		}
		else
		{
			UART1TxEmpty = 0;
		}
	}
	T1IR        = 1; 
	IDISABLE;
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*GET E SET DE CURVA DE SPO2*/
/*============================================================================*/
void Spo2::Set_curva_spo2(unsigned char value)
{
	gCurvaSpo2 = value;
}
unsigned char Spo2::Get_curva_spo2(void)
{
	return gCurvaSpo2;
}

/*GET E SET DE BPM DE SPO2*/
/*============================================================================*/
void Spo2::Set_bpm_spo2(unsigned char value)
{
	gBpmSpo2 = value;
}

unsigned char Spo2::Get_bpm_spo2(void)
{
	return gBpmSpo2;
}

/*GET E SET DE VALOR DE SPO2*/
/*============================================================================*/
void Spo2::Set_valor_spo2(unsigned char value)
{
	gValorSpo2 = value;
}

unsigned char Spo2::Get_valor_spo2(void)
{
	return gValorSpo2;
}

/*GET E SET DE PERDE DE PULSO DE SPO2*/
/*============================================================================*/
void Spo2::Set_status_spo2(unsigned char value)
{
	gStatusSpo2 = value;
}

unsigned char Spo2::Get_status_spo2(void)
{
	return gStatusSpo2;
}