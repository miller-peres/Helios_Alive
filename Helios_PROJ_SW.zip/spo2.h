
class Spo2
{	
	public:
		Spo2(void);
		void config_COM_spo2();
		void *Treat_Data_SPO2_BCI()__irq; 

		unsigned char Get_curva_spo2(void);
		void Set_curva_spo2(unsigned char value);

		unsigned char Get_bpm_spo2(void);
		void Set_bpm_spo2(unsigned char value);

		unsigned char Get_valor_spo2(void);
		void Set_valor_spo2(unsigned char value);

		unsigned char Get_status_spo2(void);
		void Set_status_spo2(unsigned char value);

	
	private:
		// vari�veis de configura��es COM	
		char port;
		char n;
		char StopBits;
		char Parity;
		long bps;
		int baud;
	
		//Variaveis SPO2
		unsigned char  gCountBCI;
		unsigned char gPlethValue;
		unsigned char gOxBar;
		unsigned int gPulseRate;
		unsigned char gSearchTooLong;
		unsigned char gProbebUnpluged;
		unsigned char gCheckSensor;
		unsigned char gSearching;
		unsigned char gPulseBeep;
		unsigned int gSpO2Value;
		unsigned int gCalculatedChecksum;
		unsigned int gReceivedChecksum;
		unsigned char gRevisionReady;
		char 		  gRevisionString[10];
		unsigned char gCurvaSpo2;
		unsigned char gValorSpo2;	
		unsigned short gBpmSpo2;	
		unsigned char gOxiModel;
		unsigned char gLostPulse;
		unsigned char gArtifact;
		unsigned char gSmallPulse; 
		
		unsigned char IIRValue, LSRValue;
		unsigned char Dummy;
		unsigned char RxDado;
		unsigned char UART1TxEmpty;
		
		unsigned char gMonitoraSpo2;
		unsigned char gDemo;
		unsigned char gStatusSpo2;
		unsigned long UART1Status;
		unsigned long UART0Count;
		int UART1Count;
};