
void AnalisaRitmo(void);
unsigned int AnalisaBuffer(void);
void VerificaEletrodos(void);


