#include "global.h"
#include "serial.h"
#include "type.h"


unsigned short ADCresult[4];
unsigned int gCanalAD = 0;
unsigned int gTempoTeclaLiga = 0;
unsigned int gLedEnf = 0;
unsigned int gLedEnfAnt = 0;
unsigned char gAlarmeFisiologico = 0;
unsigned char gBotaoDesliga = 0;
unsigned int gIndexVetor = 0;

