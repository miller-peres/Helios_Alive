#include <string.h>
#include <stdio.h>
#include <math.h>
#include "type.h"
#include "irq.h"
#include "time.h"
#include "serial.h"
#include "lpc21xx.h"
#include "global.h"
#include "timer.h"
#include "analise.h"
#include "ssp.h"
#include "i2c.h"
#include "main.h"
//#include <cstdio>

unsigned char derivacao = 0;
unsigned char i = 0;


int main(void)
{
	init_VIC();

	InitTimer(1,10000);									//quanto maior, menor a frequencia do clock
	InitTimer(0,250); 									//quanto maior, menor a frequencia do clock
													
	IO0DIR |= ( TX0 + SCK0 + MOSI0 + BUZZER + TX1 + ON_OFF + LED_ENF + LED_SPO2	+ LED_ECG +	CS_AD + LED_ON_BAT + DER_1 + DER_2 + RESET_ZIGBEE); 
	PINSEL1 &= ~0xC000000 ;								//Configura o pino P0_29 como GPIO
	//I2CInit(I2CMASTER);										// inicializa i2c
	
	while(1) 							
	{
		int i = 1000000;
	  for (i= 0; i < 1000000; i++)
		{
		
			if (i < 500000)
			{
			
			IO0SET |= DER_1;
			IO0CLR |= LED_ENF;
			IO0CLR |= LED_SPO2;
			IO0CLR |= LED_ECG;
			IO0CLR |= LED_ON_BAT;
				i++;
			}
			if (i > 500000)
			
	  
			IO0CLR |= DER_1;
			IO0SET |= LED_ENF;
			IO0SET |= LED_SPO2;
			IO0SET |= LED_ECG;
			IO0SET |= LED_ON_BAT;
			i++;
		}
		i = 1000000;
	}
	
}
