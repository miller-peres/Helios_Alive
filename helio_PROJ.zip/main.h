class leds
{
	public:
	unsigned int amarelo;
	unsigned int verde;
	unsigned int vermelho;
};
